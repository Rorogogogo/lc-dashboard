parcel ./web/index.html
